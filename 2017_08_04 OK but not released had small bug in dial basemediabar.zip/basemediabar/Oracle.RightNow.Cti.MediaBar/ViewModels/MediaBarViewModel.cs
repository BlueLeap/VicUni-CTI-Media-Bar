﻿// ===========================================================================================
//  Oracle RightNow Connect
//  CTI Sample Code
// ===========================================================================================
//  Copyright © Oracle Corporation.  All rights reserved.
// 
//  Sample code for training only. This sample code is provided "as is" with no warranties 
//  of any kind express or implied. Use of this sample code is pursuant to the applicable
//  non-disclosure agreement and or end user agreement and or partner agreement between
//  you and Oracle Corporation. You acknowledge Oracle Corporation is the exclusive
//  owner of the object code, source code, results, findings, ideas and any works developed
//  in using this sample code.
// ===========================================================================================

using System;
using System.ComponentModel.Composition;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Oracle.RightNow.Cti.MediaBar.Properties;
using Oracle.RightNow.Cti.MediaBar.Views;
using Oracle.RightNow.Cti.Model;
using System.Windows.Interop;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections;
using Oracle.RightNow.Cti.AddIn;
using RightNow.AddIns.AddInViews;
using RightNow.AddIns.Common;
using Blueleap.Finesse;
using Blueleap.Finesse.Events;
using Blueleap.Finesse.Events.Callback;
using Blueleap.Finesse.Constants;
using System.Text.RegularExpressions;

namespace Oracle.RightNow.Cti.MediaBar.ViewModels {
    [Export]
    public class MediaBarViewModel : RightNowMediaBar, IConnectionEventListner
    {        
        [Import]
        public IGlobalContext RightNowGlobalContext { get; set; }

        private readonly DispatcherTimer _timer = new DispatcherTimer();
        private int _callCount;
        private int _emailCount;
        private int _webIncidentCount;

        private bool _canChangeState;
        private bool _canChangeConnectionState = true;
        private bool _canCompleteInteraction;
        private bool _hasInteractions;
        private bool _showDialOptions;
        private bool _showAssociateOptions;
        private bool _sendStateToFinesse;
        private StaffAccountInfo staffAccount;
        private string _firstNotReadystate;               

        Finesse finesse;
        Dictionary<string, FinesseNotReadyReasonState> notReadyStates;

        public MediaBarViewModel()
        {
            initializeCommands();
            EnableContextSynchronization(SynchronizationContext.Current);
            staffAccount = null;
            _firstNotReadystate = "";
            finesse = new Finesse(this);
            _timer.Tick += timerTick;            
        }

       public AgentState CurrentAgentState
        {
            get
            {
                return _currentAgentState;
            }
            set
            {
                AgentState _prevAgentState = _currentAgentState;
                if (_currentAgentState != value)
                {
                    _currentAgentState = value;
                }
                
                string sendAgentState = ""; string notReadyReasonCode = ""; bool reasonDialogCancelled = false;
                if (_sendStateToFinesse == true)
                {
                    //PK: Clicked from DropDown
                    //Finesse Set state Not-Ready & Ready Only.
                    if (value == StandardAgentStates.NotReady)
                    {
                        sendAgentState = "NOT_READY";
                        if (notReadyStates.Count > 0)
                        {
                            var dialog = new Window();
                            dialog.ResizeMode = ResizeMode.CanResize;
                            dialog.ShowInTaskbar = false;
                            dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                            dialog.Height = 550;
                            dialog.Width = 350;
                            dialog.Title = "Not Ready - Reason Code(s)";
                            var UCdialog = new UCReasonCodeView();

                            IList<AgentState> dynamicAgentState = AgentStates.Where(p => p.SwitchMode == AgentSwitchMode.Dynamic).ToList();
                            ConsoleWindowHelper.SetupOwner(dialog);
                            UCdialog.DataContext = new UCReasonCodeViewModel(dynamicAgentState, (result, contact) =>
                            {
                                if (result)
                                {
                                    notReadyReasonCode = contact.Code;
                                    Application.Current.Dispatcher.BeginInvoke(
                                       DispatcherPriority.Background,
                                       new Action(() =>
                                       {
                                           _currentAgentState = AgentStates.Where(p => p.Code == contact.Code && p.SwitchMode == AgentSwitchMode.Dynamic).FirstOrDefault();
                                           synchronizeAndRaiseOnPropertyChanged("CurrentAgentState");
                                       })
                                   );
                                    
                                }
                                else
                                {
                                    //Do not change Not Ready state
                                    dialog.Close();
                                    reasonDialogCancelled = true;
                                }
                                dialog.Close();
                            });

                            dialog.Content = UCdialog;
                            dialog.ShowDialog();
                        }

                    }
                    else if (value == StandardAgentStates.Available)
                    {
                        sendAgentState = "READY";
                    }
                }

                //Do not change the state.
                if (reasonDialogCancelled)
                {
                    Application.Current.Dispatcher.BeginInvoke(
                                  DispatcherPriority.Background,
                                  new Action(() =>
                                  {
                                      _currentAgentState = _prevAgentState;
                                      synchronizeAndRaiseOnPropertyChanged("CurrentAgentState");
                                  })
                              );
                    return;
                }

                if (_sendStateToFinesse == true && sendAgentState.Length > 0)
                {
                    Task.Factory.StartNew(() =>
                    {
                        try
                        {
                            //PK: Connecting is an intrmediate state do not send it to Finesse.
                            if (value.SwitchMode != AgentSwitchMode.Connecting)
                            {
                                int retVal = 0;
                                if (notReadyReasonCode != "")
                                {
                                    retVal = finesse.fnAgentState(sendAgentState, notReadyReasonCode);
                                }
                                else
                                {
                                    retVal = finesse.fnAgentState(sendAgentState);
                                }

                                if (retVal < 0)
                                {
                                    Logger.Logger.Log.Info("Set CurrentAgentState: Cannot set Agent State");
                                    MessageBox.Show("Cannot set Agent's State. Please contact your administrator for help.", "BlueLeap Media Bar");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Logger.Log.Info("Set CurrentAgentState: " + ex.InnerException.ToString());
                        }
                    });
                    InteractionProvider.Agent.SetState(value);
                }

                if (_sendStateToFinesse == false)
                {
                    _sendStateToFinesse = true;
                }

                CanMakeCall = _currentAgentState.SwitchMode != AgentSwitchMode.LoggedOut && _currentAgentState.SwitchMode != AgentSwitchMode.Connecting && (_currentAgentState.SwitchMode == AgentSwitchMode.NotReady || _currentAgentState.SwitchMode == AgentSwitchMode.Dynamic);
                synchronizeAndRaiseOnPropertyChanged("CurrentAgentState");
            }
        }

        public string FinesseAgentName
        {
            get;
            set;
        }

        public int FinesseAgentExtension
        {
            get
            {
                if (InteractionProvider.Credentials != null)
                {
                    return InteractionProvider.Credentials.Extension;
                }
                return 0;
            }
            set
            {
                if (InteractionProvider.Credentials != null)
                {
                    InteractionProvider.Credentials.Extension = value;
                    OnPropertyChanged("FinesseAgentExtension");
                }
            }
        }

        public string FinesseAgentID
        {
            get
            {
                if (InteractionProvider.Credentials != null)
                {
                    return InteractionProvider.Credentials.AgentID;
                }
                return String.Empty;
            }
            set
            {
                if (InteractionProvider.Credentials != null)
                {
                    InteractionProvider.Credentials.AgentID = value;
                    OnPropertyChanged("FinesseAgentID");
                }
            }
        }

        public string AgentName {
            get {
                if (InteractionProvider.Agent != null) {
                    return InteractionProvider.Agent.Name;
                }

                return string.Empty;
            }
        }

        public AgentState TempAgentState
        {
            get;
            set;
        }

        public string FinesseConnectionStatus
        {
            get;
            set;
        }

        public int CallCount {
            get {
                return _callCount;
            }
            set {
                if (_callCount != value) {
                    _callCount = value;
                    OnPropertyChanged("CallCount");
                }
            }
        }

        public bool HasInteractions {
            get {
                return _hasInteractions;
            }
            set {
                if (_hasInteractions != value) {
                    _hasInteractions = value;
                    OnPropertyChanged("HasInteractions");
                }
            }
        }

        public int EmailCount {
            get {
                return _emailCount;
            }
            set {
                if (_emailCount != value) {
                    _emailCount = value;
                    OnPropertyChanged("EmailCount");
                }
            }
        }

        public string Extension {
            get {
                if (InteractionProvider.Device != null) {
                    return InteractionProvider.Device.Address;
                }

                return string.Empty;
            }
        }

        public bool CanChangeState {
            get {
                return _canChangeState;
            }
            set {
                _canChangeState = value;
                OnPropertyChanged("CanChangeState");
            }
        }

        public bool CanChangeConnectionState {
            get {
                return _canChangeConnectionState;
            }
            set {
                _canChangeConnectionState = value;
                OnPropertyChanged("CanChangeConnectionState");
            }
        }

        public string InteractionTime {
            get {
                if (CurrentInteraction != null) {
                    return (CurrentInteraction.Duration).ToString(@"hh\:mm\:ss");
                }

                return string.Empty;
            }
        }

        public string AnswerHangupImage {
            get {
                return (CurrentInteraction != null && CurrentInteraction.State == InteractionState.Ringing)
                       ? Resources.AnswerImageUri
                       : Resources.HangupImageUri;
            }
        }

        public string AnswerHangupTooltip {
            get {
                return (CurrentInteraction != null && CurrentInteraction.State == InteractionState.Ringing)
                       ? Resources.AnswerTooltip
                       : Resources.HangupTooltip;
            }
        }

        public string HoldRetrieveImage {
            get {
                return (CurrentInteraction != null && CurrentInteraction.State == InteractionState.Held)
                       ? Resources.RetrieveImageUri
                       : Resources.HoldImageUri;
            }
        }

        public string HoldRetrieveTooltip {
            get {
                return (CurrentInteraction != null && CurrentInteraction.State == InteractionState.Held)
                       ? Resources.RetriveTooltip
                       : Resources.HoldTooltip;
            }
        }

        public bool IsAgentLoggedIn {
            get {
                return CurrentAgentState != null && CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
            }
        }

        public bool ShowWebRTCButton
        {
            get
            {
                return MediaBarAddIn._WebRTCEnable;
            }
        }

        [Import]
        public IContactProvider ContactProvider { get; set; }

        #region Commands

        public ICommand LoginToggleCommand { get; set; }

        public ICommand AnswerHangUpCallCommand { get; set; }

        public ICommand HoldRetrieveCallCommand { get; set; }

        public ICommand CompleteInteractionCommand { get; set; }

        public ICommand ShowTransferDialogCommand { get; set; }

        public ICommand ShowDialOptionsCommand { get; set; }

        public ICommand DialCommand { get; set; }

        public ICommand ShowDialPadComand { get; set; }

        public ICommand ShowAgentLoginCommand { get; set; }
        public ICommand AssociateContactCommand { get; set; }
        public ICommand ShowAssociateContactCommand { get; set; }

        public ICommand UnassociateContactCommand { get; set; }

        #endregion Commands

        public int WebIncidentCount {
            get {
                return _webIncidentCount;
            }
            set {
                if (_webIncidentCount != value) {
                    _webIncidentCount = value;
                    OnPropertyChanged("WebIncidentCount");
                }
            }
        }

        public bool CanCompleteInteraction {
            get {
                return _canCompleteInteraction;
            }
            set {
                if (_canCompleteInteraction != value) {
                    _canCompleteInteraction = value;
                    OnPropertyChanged("CanCompleteInteraction");
                }
            }
        }

        public bool ShowDialOptions {
            get {
                return _showDialOptions;
            }
            set {

                if (_showDialOptions != value) {
                    _showDialOptions = value;
                    OnPropertyChanged("ShowDialOptions");
                }
            }
        }

        public bool ShowAssociateOptions
        {
            get
            {
                return _showAssociateOptions;
            }
            set
            {

                if (_showAssociateOptions != value)
                {
                    _showAssociateOptions = value;
                    OnPropertyChanged("ShowAssociateOptions");
                }
            }
        }

        public override void OnImportsSatisfied() {
            base.OnImportsSatisfied();
            InteractionProvider.Agent.StateChanged += agentManagerStateChanged;
            InteractionProvider.Agent.NameChanged += agentNameChanged;
            InteractionProvider.Device.AddressChanged += deviceAddressChanged;
            this.SynchronizationContext.Post(o=>ToastManager.Initialize((IInteractionProvider)o), InteractionProvider);            
            _objectProvider = new RightNowObjectProvider(RightNowGlobalContext);
            resetMediaBar();
            Task.Factory.StartNew(() =>
            {
                staffAccount = _objectProvider.GetStaffAccountInformation(RightNowGlobalContext.AccountId);
            });
        }

        protected override void InteractionConnectedHandler(object sender, InteractionEventArgs e) {
            base.InteractionConnectedHandler(sender, e);

            if (e.Interaction.IsRealTime)
                CanCompleteInteraction = false;
        }

        protected override void NewInteractionHandler(object sender, InteractionEventArgs e) {
            base.NewInteractionHandler(sender, e);
            if (!_timer.IsEnabled) {
                _timer.Interval = TimeSpan.FromSeconds(1);
                _timer.Start();
            }

            updateInteractionCount(new InteractionCountUpdateInfo {
                MediaType = e.Interaction.Type,
                UpdateType = UpdateType.Add
            });

            e.Interaction.StateChanged += interactionStateChangedHandler;
            CanChangeConnectionState = false;
            HasInteractions = true;
        }
  
        private void interactionStateChangedHandler(object sender, InteractionStateChangedEventArgs e) {
            notifyInteractionStateProperties();
        }
  
        private void notifyInteractionStateProperties() {
            OnPropertyChanged("HoldRetrieveImage");
            OnPropertyChanged("HoldRetrieveTooltip");

            OnPropertyChanged("AnswerHangupImage");
            OnPropertyChanged("AnswerHangupTooltip");
        }

        protected override void CurrentInteractionChangedHandler(object sender, InteractionEventArgs e) {
            base.CurrentInteractionChangedHandler(sender, e);
            notifyInteractionStateProperties();

            if (CurrentInteraction != null && (!CurrentInteraction.IsRealTime || CurrentInteraction.State == InteractionState.Disconnected)) {
                CanCompleteInteraction = true;
            }
            else {
                CanCompleteInteraction = false;
            }
        }

        protected override void InteractionDisconnectedHandler(object sender, Oracle.RightNow.Cti.InteractionEventArgs e) {
            base.InteractionDisconnectedHandler(sender, e);
            CanCompleteInteraction = true;
        }

        protected override void InteractionCompletedHandler(object sender, Oracle.RightNow.Cti.InteractionEventArgs e) {
            base.InteractionCompletedHandler(sender, e);
            CanCompleteInteraction = false;
            updateInteractionCount(new InteractionCountUpdateInfo {
                MediaType = e.Interaction.Type,
                UpdateType = UpdateType.Subtract
            });

            HasInteractions = InteractionProvider.Interactions.Count != 0;
            CanChangeConnectionState = !HasInteractions;
        }

        private void agentManagerStateChanged(object sender, AgentStateChangedEventArgs e) {
            OnPropertyChanged("IsAgentLoggedIn");
            CanChangeState = e.NewState.SwitchMode != AgentSwitchMode.LoggedOut;
        }

        private void agentNameChanged(object sender, EventArgs e) {
        }

        private void deviceAddressChanged(object sender, ExtensionChangedEventArgs e) {
            OnPropertyChanged("Extension");            
        }

        private void initializeCommands() {
            LoginToggleCommand = new DelegateCommand(o => ToggleLogin());
            AnswerHangUpCallCommand = new DelegateCommand(o => answerHangUpCall());
            HoldRetrieveCallCommand = new DelegateCommand(o => HoldRetrieveCall());
            CompleteInteractionCommand = new DelegateCommand(o => CompleteInteraction());
            ShowTransferDialogCommand = new DelegateCommand(showTransferDialog);
            ShowDialOptionsCommand = new DelegateCommand(o=> showDialOptions());
            DialCommand = new DelegateCommand(o => ValidateAndDial(o as Contact));
            ShowDialPadComand = new DelegateCommand(showDialPad);
            ShowAgentLoginCommand = new DelegateCommand(showAgentLoginDialog);
            ShowAssociateContactCommand = new DelegateCommand(o => showAssociateOptions());
            AssociateContactCommand = new DelegateCommand(o => associateContactCommand(o as Contact));
            UnassociateContactCommand = new DelegateCommand(o => unassociateContact());
            FinesseConnectionStatus = "Finesse: Not-Connected.";
            TempAgentState = StandardAgentStates.LoggedOut;

            var states = new List<AgentState>();
            // Add standard states. These are Finesse's Agents State
            states.Add(StandardAgentStates.Available);
            states.Add(StandardAgentStates.WrapUp);
            states.Add(StandardAgentStates.NotReady);
            states.Add(StandardAgentStates.NewReason);
            states.Add(StandardAgentStates.LoggedIn);
            states.Add(StandardAgentStates.LoggedOut);
            states.Add(StandardAgentStates.Reserved);
            states.Add(StandardAgentStates.Talking);
            states.Add(StandardAgentStates.Unknown);
            states.Add(StandardAgentStates.Connecting);

            AgentStates = states;
        }

        private void answerHangUpCall() {
            var call = InteractionProvider.CurrentInteraction as ICall;
            if (call != null) {
                if (call.State == InteractionState.Ringing)
                    call.Accept();
                else
                    call.HangUp();
            };
        }

        private void showDialPad(object obj) {
            var dialog = new TransferDialog();
            var contacts = ContactProvider.GetContacts();

            ConsoleWindowHelper.SetupOwner(dialog);
            dialog.DataContext = new TransferDialogViewModel(contacts, (result, contact) => {
                if (result) {
                    string errmsg = ""; string dialNumber = "";
                    if(ValidateNumber(contact, out dialNumber, out errmsg))
                    {
                        Dial(dialNumber);
                    }
                    else 
                    {
                        dialog.error.Text = errmsg;
                        dialog.error.Visibility = Visibility.Visible;
                        return;
                    }
                }
                dialog.Close();
            }, "Dial");

            dialog.ShowDialog();
        }

        private bool ValidateDialNumber(string number, out string msg)
        {
            if (string.IsNullOrEmpty(number))
            {
                msg = "Please enter the number!.";
                return false;
            }
            else
            {
                //string pattern = @"(?:\+?61)?(?:\(0\)[23478]|\(?0?[23478]\)?)\d{8}";
                string pattern = @"[\+]{1}";
                
                Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
                Match match = regex.Match(number);
                while (match.Success)
                {
                    string phoneNumber = match.Groups[0].Value;
                    match = match.NextMatch();
                    msg = "";
                    return true;
                }
                msg = "Not a valid number!.";
                return false;
            }
        }

        private void showDialOptions() {
            ShowDialOptions = true;
        }

        private void showAssociateOptions()
        {
            ShowAssociateOptions = true;
        }

        private void showTransferDialog(object obj) {
            var dialog = new TransferDialog();
            var contacts = ContactProvider.GetContacts();

            ConsoleWindowHelper.SetupOwner(dialog);

            dialog.DataContext = new TransferDialogViewModel(contacts, (result, contact) => {
                if (result) {
                    TransferCall(contact);
                }

                dialog.Close();
            });

            dialog.ShowDialog();
        }
 
        private void updateInteractionCount(InteractionCountUpdateInfo info) {
            Application.Current.Dispatcher.Invoke(new Action<InteractionCountUpdateInfo>((updateInfo) => {
                var updateValue = updateInfo.UpdateType == UpdateType.Add ? 1 : -1;

                switch (updateInfo.MediaType)
                {
                    case MediaType.Voice:
                        CallCount += updateValue;
                        break;
                    case MediaType.Email:
                        EmailCount += updateValue;
                        break;
                    case MediaType.Chat:
                        break;
                    case MediaType.Web:
                        WebIncidentCount += updateValue;
                        break;
                    default:
                        break;
                }
            }), info);
        }

        private void timerTick(object sender, EventArgs e) {
            OnPropertyChanged("InteractionTime");
        }

        private class InteractionCountUpdateInfo {
            public MediaType MediaType { get; set; }

            public UpdateType UpdateType { get; set; }
        }

        private enum UpdateType {
            Add,
            Subtract
        }

        //To set MediaBar to the Start Logged Out State.
        private void resetMediaBar()
        {
            FinesseAgentID = "Agent";
            FinesseAgentExtension = 0;
            finesse.fnDisconnect();
            CurrentAgentState = StandardAgentStates.LoggedOut;
            CanChangeState = CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
            FinesseConnectionStatus = "Finesse: Not-Connected.";
            OnPropertyChanged("IsAgentLoggedIn");
            OnPropertyChanged("FinesseConnectionStatus");
            CanAssociateContact = false;
            CanUnAssociateContact = false;
            _sendStateToFinesse = false;
    }
    private void showAgentLoginDialog(object obj)
        {
            if (IsAgentLoggedIn)
            {
                if (MessageBox.Show("Medibar will be disconnected with Finesse. Do you want to continue?", "BlueLeap Media Bar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    resetMediaBar();
                }
                return;
            }

            var dialog = new AgentLogin();
            var contacts = ContactProvider.GetContacts();

            WindowInteropHelper helper = new WindowInteropHelper(dialog);
            if (System.Windows.Forms.Application.OpenForms.Count > 0)
            {
                helper.Owner = System.Windows.Forms.Application.OpenForms[0].Handle;
            }
            else
            {

            }

            if (staffAccount == null)
            {
                staffAccount = _objectProvider.GetStaffAccountInformation(RightNowGlobalContext.AccountId);
            }

            if (staffAccount != null && staffAccount.FinesseAutoLogin) {
                dialog.agentIdText.Text = staffAccount.AcdId;
                dialog.passwordText.Password = staffAccount.AcdPassword;
                dialog.extensionText.Text = staffAccount.Extension;
                dialog.chkRemember.IsChecked = staffAccount.FinesseAutoLogin;
            }
            ConsoleWindowHelper.SetupOwner(dialog);
            dialog.DataContext = new AgentLoginViewModel(contacts, (result, contact) =>
            {
                if (result)
                {
                    string validationResult = Validate(dialog);
                    if (validationResult == string.Empty)
                    {
                        if(staffAccount == null)
                        {
                            staffAccount = new StaffAccountInfo();
                        }

                        bool previousCheckedState = staffAccount.FinesseAutoLogin;
                        staffAccount.AcdId = dialog.agentIdText.Text.Trim();
                        staffAccount.AcdPassword = dialog.passwordText.Password.Trim();
                        staffAccount.Extension = dialog.extensionText.Text.Trim();
                        staffAccount.FinesseAutoLogin = (bool)dialog.chkRemember.IsChecked;
                        FinesseAgentID = string.IsNullOrEmpty(staffAccount.AcdId) ? "" : staffAccount.AcdId;
                        FinesseAgentExtension = int.Parse(staffAccount.Extension);
                        InteractionProvider.Credentials.Password = staffAccount.AcdPassword;
                        FinesseConnectionStatus = String.Format("Finesse Agent {0}: Connecting...", InteractionProvider.Credentials.AgentID);
                        this.CurrentAgentState = StandardAgentStates.Connecting;
                        staffAccount.FinesseIP = MediaBarAddIn._FinesseDomain;
                        //staffAccount.FinesseIP = "devuccx.vu.edu.au";
                        //staffAccount.FinesseIP = "hq-uccx.abc.inc";
                        OnPropertyChanged("FinesseConnectionStatus");

                        if ((bool)dialog.chkRemember.IsChecked == true || (bool)dialog.chkRemember.IsChecked == false && previousCheckedState == true)
                        {
                            Task.Factory.StartNew(() =>
                            {
                                _objectProvider.UpdateStaffAccountInformation(staffAccount);
                            });
                        } else
                        {
                            //If checkbox is unchecked and if 
                        }

                        staffAccount.FinesseAutoLogin = (bool)dialog.chkRemember.IsChecked;

                        Task.Factory.StartNew(() =>
                        {
                            if(finesse.fnConnect(staffAccount.FinesseIP, 3) == 0)
                            {
                                if(finesse.fnLogin(staffAccount.AcdId, staffAccount.AcdPassword, staffAccount.Extension, "5000") < 0)
                                {
                                    Application.Current.Dispatcher.BeginInvoke(
                                        DispatcherPriority.Background,
                                        new Action(() =>
                                        {
                                            resetMediaBar();
                                            MessageBox.Show("Cannot subscribe to Finesse. Please verify your username and password.", "BlueLeap Media Bar");
                                            
                                        })
                                    );
                                } else
                                {
                                    //After successful login adding the list of notready agent state to the list of agent states
                                    notReadyStates = finesse.getNotReadyReasonCodes();
                                    foreach (var item in notReadyStates)
                                    {
                                        AgentStates.Add(new AgentState
                                        {
                                            AgentSelectable = false,
                                            Code = item.Value.Code,
                                            Description = item.Value.Label,
                                            Id = Convert.ToInt32(item.Key),
                                            IsOutboundEnabled = false,
                                            Name = "Not Ready",
                                            SwitchMode = AgentSwitchMode.Dynamic,
                                        });
                                    }

                                    if(_firstNotReadystate != null && _firstNotReadystate != "")
                                    {
                                        //For a tricky situation when we get the agent status too soon before we popluate the list items.
                                        CurrentAgentState = AgentStates.Where(p => p.Id == Convert.ToInt32(_firstNotReadystate) && p.SwitchMode == AgentSwitchMode.Dynamic).FirstOrDefault();
                                        if (CurrentAgentState == null)
                                        {
                                            Application.Current.Dispatcher.BeginInvoke(
                                            DispatcherPriority.Background,
                                            new Action(() =>
                                                {
                                                    //PK: Should not be the case.
                                                    CurrentAgentState = StandardAgentStates.NotReady;
                                                })
                                            );
                                        }
                                    }
                                }
                            } else
                            {
                                Application.Current.Dispatcher.BeginInvoke(
                                    DispatcherPriority.Background,
                                    new Action(() =>
                                    {
                                        resetMediaBar();
                                        MessageBox.Show("Cannot connect to Finesse with the URL" + staffAccount.FinesseIP + ". Please contact your administrator.");
                                     })
                                );
                            }
                        });
                    }
                    else
                    {
                        dialog.errLabel.Text = validationResult;
                        dialog.errLabel.Visibility = Visibility.Visible;
                        return;
                    }
                }

                dialog.Close();
            }, isQueueEnabled: false);

            dialog.ShowDialog();
        }

        private void associateContactCommand(Contact contact)
        {
            if (MessageBox.Show(String.Format("This will replace the contact {0} to {1}. Continue?", contact.Name, _previousCallerNumber), "BlueLeap Media Bar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                if(!updateContactRecord(contact,_previousCallerNumber))
                {
                    MessageBox.Show("Cannot associate current contact record. Please try again.", "BlueLeap Media Bar");
                }
            }
        }

        private bool unassociateContact()
        {
            try
            {
                if (_contact != null && !String.IsNullOrEmpty(_previousCallerNumber))
                {
                    if (_contact.PhMobile != null && _contact.PhMobile.Trim().Equals(_previousCallerNumber))
                    {
                        if (MessageBox.Show(String.Format("This will remove the current contact mobile number {0}. Continue?", _contact.PhMobile), "BlueLeap Media Bar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            _contact.PhMobile = "";
                            updateContactListAfterUnassoc();
                            SaveAndRefreshWorkspace();
                        }
                    }
                    else if (_contact.PhOffice != null && _contact.PhOffice.Trim().Equals(_previousCallerNumber))
                    {
                        if (MessageBox.Show(String.Format("This will remove the current contact office number {0}. Continue?", _contact.PhOffice), "BlueLeap Media Bar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            _contact.PhOffice = "";
                            updateContactListAfterUnassoc();
                            SaveAndRefreshWorkspace();
                        }
                    }
                    else if (_contact.PhHome != null && _contact.PhHome.Trim().Equals(_previousCallerNumber))
                    {
                        if (MessageBox.Show(String.Format("This will remove the current contact home number {0}. Continue?", _contact.PhOffice), "BlueLeap Media Bar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            _contact.PhHome = "";
                            updateContactListAfterUnassoc();
                            SaveAndRefreshWorkspace();
                        }
                    }
                }
            } catch (Exception ex)
            {
                MessageBox.Show("Cannot Unassociate the current contact record. Please try again.", "BlueLeap Media Bar");
                Logger.Logger.Log.Error("RightNowObjectProvider:", ex);
                return false;
            }
            return true;
        }
        private void ValidateAndDial(Contact contact)
        {
            string error = ""; string dialNumber = "";
            if (ValidateNumber(contact, out dialNumber, out error))
            {
                Dial(dialNumber);
            }
            else
            {
                MessageBox.Show(error,"BlueLeap Media Bar");
            }
        }

        private bool ValidateNumber(Contact contact, out string dialNumber, out string errMsg)
        {
            errMsg = ""; dialNumber = contact.Number;

            if (string.IsNullOrEmpty(dialNumber) || dialNumber.Length < 4)
            {
                errMsg = "Not a valid number.";
                return false;
            }
            if (dialNumber.Length == 4)
            {
                //Extension Number. Do Nothing.
            }
            else
            {
                string pattern = @"[\"+MediaBarAddIn._InternationalPrefix+"]{1}";
                Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
                Match match = regex.Match(dialNumber);
                if (match.Success)
                {
                    //Valid Interational Format Number. Proceed with Dial. Do not do anything.
                }
                else
                {
                    //Prefix 0 to Dial number.
                    dialNumber = string.Format("{0}{1}", MediaBarAddIn._OutsidePrefix,dialNumber);
                }
            }
            return true;
        }


        /// <summary>
        /// Initiates an outbound dial request.
        /// </summary>
        /// <param name="contact">The contact to be dialed.</param>
        private void Dial(string contactNumber)
        {
            Task.Factory.StartNew(() => {
                finesse.fnMakeCall(contactNumber.Trim());
            });
        }

        private string Validate(AgentLogin dialog)
        {
            string result = string.Empty;
            string missingFields = string.Empty;
            if (dialog.extensionText.Text.Trim() == "")
            {
                if (missingFields == string.Empty)
                {
                    missingFields = "Extension";
                }
                else
                {
                    missingFields = missingFields + "," + "Extension";
                }
            }

            if (dialog.agentIdText.Text.Trim() == "")
            {
                if (missingFields == string.Empty)
                {
                    missingFields = "Agent Id";
                }
                else
                {
                    missingFields = missingFields + "," + "Agent Id";
                }
            }

            if (dialog.passwordText.Password.Trim() == "")
            {
                if (missingFields == string.Empty)
                {
                    missingFields = "Password";
                }
                else
                {
                    missingFields = missingFields + "," + "Password";
                }
            }

            if (missingFields != string.Empty)
            {
                result = "Missing field(s): " + missingFields;
            }

            return result;
        }

        public void GetEventOnCallWrapUp(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {
            Logger.Logger.Log.Info("GetEventOnCallWrapup");
        }

        public void GetEventOnCallHeld(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }

        public void GetEventOnCallInitiating(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }

        public void GetEventOnCallInitiated(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }

        public void GetEventOnCallFailed(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }
        public void GetEventOnPassCheck(string ret, string data)
        {

        }


        public void GetEventOnCallActive(Event evt)
        {
            Logger.Logger.Log.Info("GetEventOnCallActive" + evt.getEvtMsg());
        }

        public void GetEventOnCallAlerting(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {
            Application.Current.Dispatcher.BeginInvoke(
                     DispatcherPriority.Background,
                     new Action(() =>
                     {
                         //PK: Screen popup of contact. Does not work in a Thread.
                         Hashtable callVariables = table;
                         string studentId = callVariables["callVariable2"].ToString();
                         string fromphoneNumber = callVariables["callVariable4"].ToString();
                         int reportId = 104398;
                         try
                         {
                             reportId = Convert.ToInt32(MediaBarAddIn._reportID);
                         }
                         catch (Exception ex)
                         {

                         }

                         string pattern = @"[\" + MediaBarAddIn._InternationalPrefix + "]{1}";
                         Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
                         Match match = regex.Match(fromphoneNumber);
                         if (match.Success)
                         {
                             //Valid Interational Format Number. Do not do anything.
                         }
                         else
                         {
                             //Delete leading 0 from the Dial Number
                             if (fromphoneNumber.Substring(0, 1).Equals("0"))
                             {
                                 fromphoneNumber = fromphoneNumber.Substring(1);
                             }

                         }

                         OpenContact(studentId, fromphoneNumber, reportId);
                         Logger.Logger.Log.Info("GetEventOnCallAlerting" + callType);
                     })
                );
        }
        public void GetEventOnCallEstablished(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }
        public void GetEventOnCallDropped(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table)
        {

        }

        public void GetEventOnAgentStateChange(string state, string reasonCode, string evtMessage)
        {
            TempAgentState = StandardAgentStates.NotReady;
            if (state.Equals("NOT_READY"))
            {
                //Handling of Not-Ready States
                TempAgentState = StandardAgentStates.NotReady;
                //Reason code is not ready on the UI so store the reason code to update when the states are available.
                if (notReadyStates == null )
                {
                    if (!string.IsNullOrEmpty(reasonCode))
                    {
                        _firstNotReadystate = reasonCode;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(reasonCode))
                    {
                        TempAgentState = AgentStates.Where(p => p.Id == Convert.ToInt32(reasonCode) && p.SwitchMode == AgentSwitchMode.Dynamic).FirstOrDefault();
                        if (TempAgentState == null)
                        {
                            //Should not be the case.
                            TempAgentState = StandardAgentStates.NotReady;
                        }
                    }
                }
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: Not-Ready.", InteractionProvider.Credentials.AgentID);
            }
            else if (state.Equals("READY"))
            {
                TempAgentState = StandardAgentStates.Available;
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: Ready.", InteractionProvider.Credentials.AgentID);
            }
            else if (state.Equals("HOLD"))
            {
                TempAgentState = StandardAgentStates.Hold;
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: Ready.", InteractionProvider.Credentials.AgentID);
            }
            else if (state.Equals("RESERVED"))
            {
                TempAgentState = StandardAgentStates.Reserved;
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: Reserved.", InteractionProvider.Credentials.AgentID);
            }
            else if (state.Equals("WORK"))
            {
                TempAgentState = StandardAgentStates.WrapUp;
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: WrapUp.", InteractionProvider.Credentials.AgentID);
            }

            else if (state.Equals("LOGOUT"))
            {
                TempAgentState = StandardAgentStates.LoggedOut;
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: LoggedOut.", InteractionProvider.Credentials.AgentID);
            }
            else if (state.Equals("LOGIN"))
            {
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: LoggedIn.", InteractionProvider.Credentials.AgentID);
                TempAgentState = StandardAgentStates.LoggedIn;                
            }
            else if (state.Equals("TALKING"))
            {
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: In Call (Talking).", InteractionProvider.Credentials.AgentID);
                TempAgentState = StandardAgentStates.Talking;
            }
            else
            {
                FinesseConnectionStatus = String.Format("Finesse Agent {0}: Not-Ready.", InteractionProvider.Credentials.AgentID);
                TempAgentState = StandardAgentStates.NotReady;
            }
            if (this.CurrentAgentState != TempAgentState)
            {
                Application.Current.Dispatcher.BeginInvoke(
                    DispatcherPriority.Background,
                    new Action(() =>
                    {
                        AgentState previousAgentState = this.CurrentAgentState;
                        _sendStateToFinesse = false;
                        this.CurrentAgentState = TempAgentState;
                        OnPropertyChanged("IsAgentLoggedIn");
                        OnPropertyChanged("FinesseConnectionStatus");
                        CanChangeState = CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
                        if(CurrentAgentState == StandardAgentStates.LoggedOut)
                        {
							//PK: Can be removed for Auto Connect after Desktop Login.
                            resetMediaBar();
                            //Connecting failed. Probable reason not logged in from phone.
                            if (previousAgentState == StandardAgentStates.Connecting)
                            {
                                MessageBox.Show("Please login to Finesse Agent Desktop with the same AgentID/username before subscribing.", "BlueLeap Media Bar");
                            } else
                            {
                                MessageBox.Show("You probably signed out from Finesse. Media Bar disconnected.", "BlueLeap Media Bar");
                            }
                        }
                    })
                );
            } 
        }

        public void GetEventOnCallError(string errorMessage)
        {

        }
        public void GetEventOnError(Event evt)
        {
            Application.Current.Dispatcher.BeginInvoke(
                   DispatcherPriority.Background,
                   new Action(() =>
                   {
                       resetMediaBar();
                       MessageBox.Show("Error with communicating with Finesse + " + evt);
                   })
               );
        }

        public void GetEventOnConnection(string finesseIP, String evt)
        {
            Logger.Logger.Log.Info("GetEventOnConnection event" + evt);
        }

        public void GetEventOnDisConnection(string finesseIP, String evt)
        {
            Application.Current.Dispatcher.BeginInvoke(
                    DispatcherPriority.Background,
                    new Action(() =>
                    {
                        this.CurrentAgentState = StandardAgentStates.LoggedOut;
                        OnPropertyChanged("IsAgentLoggedIn");
                        CanChangeState = CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
                    })
                );
            Logger.Logger.Log.Info("GetEventOnDisConnection " + finesseIP + " event" + evt);
        }
        public void GetEventOnFinesseConnectionProblem(Event evt)
        {
            Application.Current.Dispatcher.BeginInvoke(
                    DispatcherPriority.Background,
                    new Action(() =>
                    {
                        this.CurrentAgentState = StandardAgentStates.LoggedOut;
                        OnPropertyChanged("IsAgentLoggedIn");
                        CanChangeState = CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
                        MessageBox.Show("Cannot connect to Finesse.", "BlueLeap Media Bar");
                    })
                );
            Logger.Logger.Log.Info("GetEventOnFinesseConnectionProblem event" + evt);
        }

        public void getcontactid(IGlobalContext _globalContext, IRecordContext _recordContext)
        {
            
            //_contact = _recordContext.GetWorkspaceRecord(WorkspaceRecordType.Contact) as IContact;
            //string _sc_contactid = null;
            //foreach (var _item in _contact.CustomField)
            //{
            //    if (_item.CfId == 53)
            //    {
            //        _sc_contactid = _item.ValStr;
            //    }
            //}

            //if (_sc_contactid != null)
            //{
            //    foreach (var item in _contact.CustomField)
            //    {
            //        if (item.CfId == 53)
            //        {
            //            item.ValStr = _sc_contactid;
            //        }

            //    }
            //}
        }

        public void GetEventOnFinesseConnectionProblem(string finesseIP)
        {
            Application.Current.Dispatcher.BeginInvoke(
                    DispatcherPriority.Background,
                    new Action(() =>
                    {
                        this.CurrentAgentState = StandardAgentStates.LoggedOut;
                        OnPropertyChanged("IsAgentLoggedIn");
                        CanChangeState = CurrentAgentState.SwitchMode != AgentSwitchMode.LoggedOut;
                        MessageBox.Show("Cannot connect to Finesse.", "BlueLeap Media Bar");
                    })
                );
            Logger.Logger.Log.Info("GetEventOnFinesseConnectionProblem event" + finesseIP);
        }
    }
}