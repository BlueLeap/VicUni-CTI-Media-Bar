﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blueleap.Finesse.Events.Callback
{
    public interface IConnectionEventListner
    {
        //CALL
        void GetEventOnConnection(string finesseIP, String evt);
        void GetEventOnDisConnection(string finesseIP, String evt);
        void GetEventOnCallAlerting(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallEstablished(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        
        void GetEventOnCallDropped(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallWrapUp(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallHeld(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallInitiating(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallInitiated(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        void GetEventOnCallFailed(string dialogID, string callType, string fromAddress, string toAddress, Hashtable table);
        
        void GetEventOnPassCheck(string ret, string data);
        
        
        void GetEventOnAgentStateChange(string state, string reasonCode, string evtMessage);
        
        void GetEventOnCallError(string errorMessage);
        void GetEventOnFinesseConnectionProblem(string finesseIP);
    }
}
