﻿using System;
using System.AddIn;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using Oracle.RightNow.Cti.MediaBar;
using Oracle.RightNow.Cti.Properties;
using RightNow.AddIns.AddInViews;
using RightNow.AddIns.Common;

namespace Oracle.RightNow.Cti.AddIn {
    [AddIn("BlueLeap Media Bar", Publisher = "Blueleap", Version = "1.0.0.0")]
    public class MediaBarAddIn : IGlobalDockWindowControl {
        private IGDWContext _dockWindowContext;
        private CompositionContainer _container;
        public static string _reportID;
        public static string _FinesseDomain;
        public static string _OutsidePrefix;
        public static string _InternationalPrefix;
        public static bool _WebRTCEnable;
        public bool Initialize(IGlobalContext context) {
            GlobalContext = context;
            _reportID = this.ReportID;
            _FinesseDomain = this.FinesseDomain;
            _OutsidePrefix = this.OutsidePrefix;
            _InternationalPrefix = this.InternationalPrefix;
            _WebRTCEnable = false;

            if (String.IsNullOrEmpty(this.WebRTCEnable))
            {
                string webRTCEnable = this.WebRTCEnable.Trim().ToLower();
                if(webRTCEnable.Equals("true") || webRTCEnable.Equals("yes") || webRTCEnable.Equals("1"))
                {
                    _WebRTCEnable = true;
                }
            }
                
            Logger.Logger.Configure(System.Reflection.Assembly.GetExecutingAssembly().Location);
            return true;
        }

        private void initializeContainer()
        {
            var baseCatalog = new AggregateCatalog();
            var info = Directory.GetParent(Path.GetDirectoryName(typeof(MediaBarAddIn).Assembly.Location));

            DirectoryInfo catalogRoot = null;
            GlobalContext.LogMessage("Multi-Channel Toolkit: Initializing container.");
            // Change to support network directories....
            if (info.Parent.FullName.StartsWith("\\\\"))
            {
                GlobalContext.LogMessage(string.Format("Multi-Channel Toolkit: UNC path deployment ({0}). Moving add-in files.", info.Parent));
                var temp = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString()));
                GlobalContext.LogMessage(string.Format("Target container direcory:", temp));

                var directories = info.Parent.GetDirectories("*", SearchOption.AllDirectories);

                foreach (var dir in directories)
                {
                    string targetDir = dir.FullName.Replace(info.Parent.FullName, temp.FullName);
                    Directory.CreateDirectory(targetDir);

                    var directoryFies = dir.GetFiles();

                    foreach (var file in directoryFies)
                    {
                        try
                        {
                            File.Copy(file.FullName, Path.Combine(targetDir, file.Name));
                        }
                        catch (Exception exc)
                        {
                            GlobalContext.LogMessage(string.Format("Failed to copy file {0}. Error: {1}", file.Name, exc.Message));
                        }
                    }
                }

                catalogRoot = temp;
            }
            else
            {
                GlobalContext.LogMessage(string.Format("Multi-Channel Toolkit: Local path deployment ({0}).", info.Parent));

                catalogRoot = info.Parent;
            }

            addDirectoryToCatalog(catalogRoot, baseCatalog);

            _container = new CompositionContainer(baseCatalog);
            try
            {
                _container.ComposeParts(this);
            }
            catch (CompositionException exc)
            {
                GlobalContext.LogMessage(exc.ToString());
                throw;
            }
        }

        private void addDirectoryToCatalog(DirectoryInfo directoryInfo, AggregateCatalog catalog) {
            catalog.Catalogs.Add(new DirectoryCatalog(directoryInfo.FullName));

            foreach (var directory in directoryInfo.GetDirectories()) {
                addDirectoryToCatalog(directory, catalog);
            }
        }

        public Control GetControl() {
            if (_container == null) {
                initializeContainer();
            }
            return MediaBar.GetView(_dockWindowContext);
        }

        public void SetGDWContext(IGDWContext context) {
            _dockWindowContext = context;
            _dockWindowContext.Docking = DockingType.Top;
            _dockWindowContext.Title = Resources.MediaBarTitle;
        }

        public void ShortcutActivated() {
        }

        [Export]
        public IGlobalContext GlobalContext { get; set; }

        [Import]
        public IMediaBarProvider MediaBar { get; set; }

        public string GroupName {
            get {
                return Resources.MediaBarGroupName;
            }
        }

        public int Order {
            get {
                return 0;
            }
        }

        public Keys Shortcut {
            get {
                return Keys.None;
            }
        }

        [ServerConfigProperty(DefaultValue = "devuccx.vu.edu.au")]
        public string FinesseDomain { get; set; }

        [ServerConfigProperty(DefaultValue = "104398")]
        public string ReportID { get; set; }

        [ServerConfigProperty(DefaultValue = "0")]
        public string OutsidePrefix { get; set; }
        [ServerConfigProperty(DefaultValue = "+")]
        public string InternationalPrefix { get; set; }
        [ServerConfigProperty(DefaultValue = "false")]
        public string WebRTCEnable { get; set; }
    }
}