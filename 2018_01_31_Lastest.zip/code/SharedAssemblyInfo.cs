﻿using System.Reflection;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BlueLeap")]
[assembly: AssemblyProduct("BlueLeap CTI Mediabar")]
[assembly: AssemblyCopyright("Copyright © 2012 BlueLeap Corporation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
