﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oracle.RightNow.Cti.MediaBar.ViewModels
{
    class ManageCampaignViewModel : ViewModel
    {
        public ManageCampaignViewModel(Action<bool> resultHandler, RightNowObjectProvider rnObject)
        {
        }
    }
}
